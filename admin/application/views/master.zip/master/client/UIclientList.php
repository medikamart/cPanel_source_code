
<!-- samir todat work date(05/01/2020) -->

<!-- BEGIN: Content--> 
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-left mb-0">Client</h2>
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url()?>Dashboard">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active">Client
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <!-- Input Validation start -->
            <section id="basic-datatable">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">CLIENT LIST</h4>
                                <a class="iq-bg-primary" data-toggle="modal" data-target="#addClient"><i class="fa fa-user-plus" style="color: #3498DB; font-size: 200%;"></i></a>
                            </div>
                            <div class="card-content">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table class="table zero-configuration">
                                            <thead align="center">
                                                <tr>
                                                    <th>Sl.No.</th>
                                                    <th>Clint ID</th>
                                                    <th>Client Name</th>
                                                    <th>Client Number</th>
                                                    <th>Address</th>
                                                    <th>Pancard Number</th>
                                                    <th>GST Number</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                           <tbody align="center">
                                            <?php 
                                              $i=0;
                                              foreach ($clientList as $key => $value) 
                                              {
                                                ?>
                                                <tr>
                                                  <td><?php echo $i++; ?></td>
                                                  <td><?php echo $value['client_id']; ?></td>
                                                  <td><?php echo $value['client_name']; ?></td>
                                                  <td><?php echo $value['contact_no']; ?></td>
                                                  <td><?php echo $value['address']; ?></td>
                                                  <td><?php echo $value['pan_no']; ?></td>
                                                  <td><?php echo $value['gst_no']; ?></td>
                                                </tr>
                                                <?php
                                              }
                                             ?>
                                           </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Input Validation end -->

        </div>
    </div>
</div>
                       <div class="modal fade" id="addClient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog" role="document">
                                             <div class="modal-content">
                                                <div class="modal-header">
                                                   <h5 class="modal-title" id="exampleModalLabel">Add New Client</h5>
                                                   <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                   <span aria-hidden="true">&times;</span>
                                                   </button>
                                                </div>
                                                <form method="post" name="registration" id="doc_validation" action="<?php echo base_url(); ?>master/client/Client/addclient">
                                                <div class="modal-body">
                                                 <div class="row">
                                                  <div class="form-group col-md-6">
                                                    <label style="font-weight: bold; color: black;">Client Name</label>
                                                   <input  maxlength="100" type="text" name="client" id="client" required="required" class="form-control" placeholder="Enter client name"/>
                                                  </div>
                                                  <div class="form-group col-md-6">
                                                    <label style="font-weight: bold; color: black;">Phone Number</label>
                                                   <input  maxlength="100" type="number" name="number" id="number" required="required" class="form-control" placeholder="Enter phone number"/>
                                                  </div>
                                                  <div class="form-group col-md-6">
                                                    <label style="font-weight: bold; color: black;">Pancard Number</label>
                                                   <input  maxlength="100" type="text" name="pannumber" id="pannumber" required="required" class="form-control" placeholder="Enter pan number"/>
                                                  </div>
                                                  <div class="form-group col-md-6">
                                                    <label style="font-weight: bold; color: black;">Address</label>
                                                    <textarea name="address" id="address" class="form-control" rows="1"></textarea>
                                                  </div>

                                                  <div id="gst_no_area" class="form-group col-md-6">
                                                
                                                  </div>



                                                  <div class="form-group col-md-6">
                                                    <button onclick="add_gst_field()" type="button" class="btn btn-primary btn-sm" data-model="toolpit" data-original-title="Add GST" id="addGst" style="margin-top: 7px; padding-right: 8px; padding-left: 8px;"><i class="fa fa-plus-square fa-2" style="font-size:200%; margin-top: 2px; margin-bottom: 2px;"></i></button>
                                                  </div>

                                                 </div>
                                                </div>
                                                <div class="modal-footer">
                                                  <button  type="submit" name="submit" class="btn btn-success" value="submit" >Add</button>
                                                </div>
                                                </form>
                                             </div>
                                          </div>
                    </div>

                    <div class="modal fade" id="editClient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog" role="document">
                                             <div class="modal-content">
                                                <div class="modal-header">
                                                   <h5 class="modal-title" id="exampleModalLabel">Edit Client</h5>
                                                   <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                   <span aria-hidden="true">&times;</span>
                                                   </button>
                                                </div>
                                                <div class="modal-content" id="model_clientData">
                                                    
                                                </div>
                                                </div>
                                          </div>
                                        </div>


<script type="text/javascript">
var c = 0;
add_gst_field();
function add_gst_field()
{
    $('#gst_no_area').append('<label id="lbl_gst_'+c+'" style="font-weight: bold; color: black;">GST Number</label>'+
        '<span onclick="remove_me('+c+')" id="dbtn_'+c+'" style="cursor:pointer;" class="badge badge-danger float-right">X</span>'+
       '<input id="inp_gst_'+c+'"  maxlength="100" type="text" name="gst_no[]" onkeyup="gstGstNo();" id="gstnumber" required="required" class="form-control" placeholder="Enter gst number"/><hr id="hr_'+c+'">');
    c++;
}

function remove_me(id)
{
    $('#lbl_gst_'+id).remove();
    $('#dbtn_'+id).remove();
    $('#inp_gst_'+id).remove();
    $('#hr_'+id).remove();
}
</script>

<script type="text/javascript">
    function editClient(client_Id)
    {
        $.ajax({
        url:"<?php echo base_url();?>master/client/Client/editCLient",
        method:"POST",
        data:{client_Id: client_Id},
        success:function(data){
            console.log(data);
            $('#model_clientData').html(data);
            }
        })
    }
</script>


<!-- <td> -->
                                                      <!-- <a data-toggle="modal" data-target="#editClient" id="" onclick="editClient(this.id);"><i class="fa fa-pencil-square-o" style="color:#0000ffa1; font-size:20px;"></i></a> -->

                                                      <!-- <a href="<?php echo base_url(); ?>master/client/Client/clientStatus/<?= $value['client_id']; ?>" data-model="toolpit"><i class="fa fa-trash" style="color:red; font-size:20px;"></i></a>
                                                     </td> -->
